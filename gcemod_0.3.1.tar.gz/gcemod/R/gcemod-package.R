#' gcemod: Generalized Competing Event Models with Lunn-McNeil Testing
#'
#' The \pkg{gcemod} package fits generalized competing event (GCE) models and
#' estimates covariate effects on \eqn{\omega^{+}}, the ratio of the hazard for
#' an event of interest to the hazard for a competing event, on both the
#' cause-specific (\code{\link{gcecox}}) and subdistribution
#' (\code{\link{gcefg}}) hazard scales.
#'
#' \deqn{\omega^{+} = h_{1}(t) / h_{2}(t)} is the hazard for the event of
#' interest relative to the hazard for the competing event. Per-subject
#' \eqn{\omega = \omega^{+} / (1 + \omega^{+})} is retained as a descriptive
#' quantity (the fraction of hazard attributable to the event of interest) for
#' comparison of model-predicted with observed values; covariate effects are
#' modeled on \eqn{\omega^{+}} only.
#'
#' Confidence intervals and p-values come from the Lunn-McNeil (1995)
#' stacked/augmented data construction: a single model on subject records
#' duplicated by event type and stratified by event type, whose
#' covariate-by-event-type interaction estimates the log ratio of
#' \eqn{\omega^{+}}. See \code{\link{lunnmcneil}}.
#'
#' @section Key functions:
#' \describe{
#'   \item{\code{\link{gcecox}}}{GCE model via cause-specific Cox regression.}
#'   \item{\code{\link{gcefg}}}{GCE model via Fine-Gray regression.}
#'   \item{\code{\link{gcecif}}}{GCE model on the cumulative-incidence scale:
#'     covariate effects on the ratio \eqn{\rho(t) = F_1(t)/F_2(t)} by
#'     pseudo-observation regression.}
#'   \item{\code{\link{lunnmcneil}}}{Stacked-model estimator and tests.}
#'   \item{\code{\link{gce_cutpoints}}}{Risk-score cutpoints maximizing omega+ separation.}
#'   \item{\code{\link{gce_alligator}}}{Cumulative incidence by risk group.}
#'   \item{\code{\link{gce_calibration}}}{Predicted vs. observed omega+ by rank.}
#'   \item{\code{\link{gce_performance}}}{Cause-specific concordance (C-index).}
#'   \item{\code{\link{gce_scaling}}}{Covariate means/SDs behind the risk score.}
#'   \item{\code{\link{gce_riskscore}}}{Score new subjects vs. the average patient.}
#'   \item{\code{\link{gce_tidy}}}{Tidy coefficient tables, including the
#'     primary/competing/total/relative effects comparison (\code{effects = TRUE}).}
#' }
#'
#' @references
#' Lunn M, McNeil D (1995) Applying Cox regression to competing risks.
#' \emph{Biometrics} 51:524-32. \doi{10.2307/2532940}
#'
#' Carmona R, Gulaya S, Murphy JD, et al. (2014) Validated competing event model
#' for the stage I-II endometrial cancer population.
#' \emph{Int J Radiat Oncol Biol Phys} 89:888-98. \doi{10.1016/j.ijrobp.2014.03.047}
#'
#' Carmona R, Zakeri K, Green G, et al. (2016) Improved method to stratify
#' elderly patients with cancer at risk for competing events.
#' \emph{J Clin Oncol} 34:1270-77. \doi{10.1200/JCO.2015.65.0739}
#'
#' Mell LK, Shen H, Nguyen-Tan PF, et al. (2019) Nomogram to predict the benefit
#' of intensive treatment for locoregionally advanced head and neck cancer.
#' \emph{Clin Cancer Res} 25:7078-7088. \doi{10.1158/1078-0432.CCR-19-1832}
#'
#' Zakeri K, Rotolo F, Lacas B, et al. (2020) Predictive classifier for intensive
#' treatment of head and neck cancer. \emph{Cancer} 126:5263-5273.
#' \doi{10.1002/cncr.33212}
#'
#' Mell LK, Pugh SL, Jones CU, et al. (2024) Effects of androgen deprivation
#' therapy on prostate cancer outcomes according to competing event risk:
#' secondary analysis of a phase 3 randomised trial.
#' \emph{Eur Urol} 85:373-381. \doi{10.1016/j.eururo.2023.01.020}
#'
#' @keywords internal
#' @import survival cmprsk ggplot2
#' @importFrom stats coef complete.cases kruskal.test model.matrix pchisq pnorm predict
#' @importFrom stats qnorm quantile reformulate sd stepfun vcov
"_PACKAGE"
